import pywhatkit as kit
# kit.search('large shiva temple in bangalore')
# kit.playonyt('billgates speech')
# kit.info('blockchain')
kit.sendwhatmsg('+919845113174','good morning mam',10,38)