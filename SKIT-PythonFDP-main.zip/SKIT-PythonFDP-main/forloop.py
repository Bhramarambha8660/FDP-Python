countries=['India','Japan','America','France','China']
# country whose name ends with a-India,America,China
for country in countries:
    if country.endswith('a'):
        print(country)