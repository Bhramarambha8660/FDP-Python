a=5
while a<8:
    print(a)
    a=a+1