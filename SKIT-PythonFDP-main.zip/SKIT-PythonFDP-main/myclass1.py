class Person:
    pass

p=Person()
