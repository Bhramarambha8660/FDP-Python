import calculator
s=calculator.add(10,20)
print(s)
