import turtle as t
t.color('red','yellow')
t.begin_fill()
for i in range(4):
    t.forward(200)
    t.right(90)
t.end_fill()
t.mainloop()
