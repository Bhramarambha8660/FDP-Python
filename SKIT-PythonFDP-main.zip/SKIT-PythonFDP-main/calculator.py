def add(a,b):
    return a+b

def sub():
    c,d=10,5
    print(c-d)




