ch=int(input('enter your choice:'))
match(ch):
    case 1:
        print('favourite food is biriyani')
    case 2:
        print('favourite place is Switzerland')
    case 3:
        print('favourite sweet is Rasgulla')
    case _:
        print('invalid choice')
