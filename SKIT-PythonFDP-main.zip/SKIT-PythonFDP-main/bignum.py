# biggest among 3 nos
a,b,c=10,20,30
if a>b and a>c:
   print('a is big')
elif b>a and b>c:
   print('b is big')
else:
   print('c is big')